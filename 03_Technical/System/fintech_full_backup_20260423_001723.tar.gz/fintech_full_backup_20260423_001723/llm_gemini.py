import os
from google import genai

API_KEY = os.environ.get("GEMINI_API_KEY")
MODEL = "gemini-2.5-flash"

client = genai.Client(api_key=API_KEY)

def gemini_ask(prompt: str, system: str = "", model: str = MODEL) -> str:
    """
    最简单、兼容当前 SDK 的写法：
    - 如果有 system，就把它和用户问题拼成一个长 prompt
    - contents 直接传字符串
    """
    if system:
        full_prompt = f"{system}\n\n用户问题：{prompt}"
    else:
        full_prompt = prompt

    resp = client.models.generate_content(
        model=model,
        contents=full_prompt,   # 直接传字符串
    )
    return resp.text

if __name__ == "__main__":
    ans = gemini_ask(
        "用一句话介绍你自己。",
        system="你是一个友好的中文助手，用简洁自然的中文回答。"
    )
    print(ans)
