import ollama
import time

# ========== 配置 ==========
MODEL_MAIN = "qwen2.5:7b"
MODEL_ALT  = "llama3.1:8b"
# ==========================

def test_generate(model, prompt, label=""):
    print(f"\n{'='*50}")
    print(f"模型：{model}")
    if label:
        print(f"测试：{label}")
    print(f"提问：{prompt}")
    print(f"{'─'*50}")
    t0 = time.time()
    resp = ollama.generate(model=model, prompt=prompt)
    elapsed = time.time() - t0
    answer = resp["response"]
    print(answer)
    print(f"\n⏱ 耗时：{elapsed:.1f}s  tokens: {resp.get('eval_count', '?')}")
    return answer

def test_chat(model, messages, label=""):
    print(f"\n{'='*50}")
    print(f"模型：{model}")
    if label:
        print(f"测试：{label}")
    for m in messages:
        print(f"[{m['role']}] {m['content'][:80]}")
    print(f"{'─'*50}")
    t0 = time.time()
    resp = ollama.chat(model=model, messages=messages)
    elapsed = time.time() - t0
    answer = resp["message"]["content"]
    print(answer)
    print(f"\n⏱ 耗时：{elapsed:.1f}s")
    return answer

print("========== Ollama 模型响应测试 ==========\n")

# --- 测试1：基础中文对话 ---
test_generate(MODEL_MAIN, "用一句话介绍你自己。", "基础中文对话")

# --- 测试2：金融知识问答 ---
test_generate(MODEL_MAIN,
    "请简要解释什么是移动平均线（MA20），以及它在A股技术分析中的用途，100字以内。",
    "金融知识问答")

# --- 测试3：代码生成 ---
test_generate(MODEL_MAIN,
    "用Python写一个函数，输入收盘价列表，返回N日移动平均线列表，处理前N-1天返回None。",
    "代码生成")

# --- 测试4：多轮对话（chat模式）---
test_chat(MODEL_MAIN, [
    {"role": "user",      "content": "沪深300指数有多少只成份股？"},
    {"role": "assistant", "content": "沪深300指数由300只A股成份股组成。"},
    {"role": "user",      "content": "这300只股票是怎么选出来的？"},
], "多轮对话")

# --- 测试5：切换到 llama3.1 ---
test_generate(MODEL_ALT,
    "What is the Sharpe ratio? Explain in 2 sentences.",
    "llama3.1 英文问答")

print("\n========== 全部测试完成 ==========")
