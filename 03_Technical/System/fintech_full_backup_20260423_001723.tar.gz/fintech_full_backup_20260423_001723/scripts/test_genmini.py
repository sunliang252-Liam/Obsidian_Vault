import os
import time
from google import genai

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
MODEL = "gemini-2.0-flash"

def ask(prompt, label=""):
    print(f"\n{'='*50}")
    print(f"测试：{label}")
    print(f"提问：{prompt[:60]}")
    print(f"{'─'*50}")
    t0 = time.time()
    resp = client.models.generate_content(model=MODEL, contents=prompt)
    elapsed = time.time() - t0
    print(resp.text)
    print(f"\n⏱ 耗时：{elapsed:.2f}s")
    return resp.text

print("========== Gemini API 测试 ==========")

ask("用一句话介绍你自己。", "基础中文对话")

ask(
    "请简要解释什么是移动平均线（MA20），以及它在A股技术分析中的用途，100字以内。",
    "金融知识问答"
)

ask(
    "用Python写一个函数，输入收盘价列表，返回N日移动平均线列表，处理前N-1天返回None。",
    "代码生成"
)

ask(
    "分析以下A股数据并给出简短建议：股票000001，最近5日收盘价：12.1, 12.3, 12.0, 11.8, 12.5，成交量逐日放大。",
    "金融数据分析"
)

print("\n========== 测试完成 ==========")
