import sys
from pathlib import Path
from sqlalchemy import create_engine, text
import pandas as pd

# 加项目根目录
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from strategies_ma_cross import detect_ma5_cross_ma20_with_volume
from llm_gemini import gemini_ask

DB_URL = "postgresql+psycopg2://postgres:fintech123@localhost:5432/fintech_db"
TABLE_NAME = "stock_daily"
engine = create_engine(DB_URL)

def load_stock(ts_code: str, days: int = 60) -> pd.DataFrame:
    sql = text(f"""
        SELECT ts_code, trade_date, close, vol
        FROM {TABLE_NAME}
        WHERE ts_code = :code
        ORDER BY trade_date DESC
        LIMIT :limit
    """)
    with engine.connect() as conn:
        df = pd.read_sql(sql, conn, params={"code": ts_code, "limit": days})
    if df.empty:
        return df
    return df.sort_values("trade_date")

def main():
    code = "600519.SH"
    name = "贵州茅台"
    df = load_stock(code, days=60)
    print(f"{code} {name} 最近 {len(df)} 日")

    logic = detect_ma5_cross_ma20_with_volume(df, lookback=5)
    print("策略结果：", logic)

    # 用 Gemini 做一句话解释
    if logic["has_signal"]:
        prompt = f"""
股票：{code}（{name}）
最近60日价格和成交量数据已用于计算 MA5、MA20 和 5日均量。

策略结果：
- 在最近 5 个交易日内出现 MA5 上穿 MA20（金叉），且当日成交量明显放大。
- 发生日期：{logic['cross_date']}
- 最新收盘价：{logic['last_close']:.2f}
- 最新 MA5：{logic['last_ma5']:.2f}，MA20：{logic['last_ma20']:.2f}

请用不超过100字，站在稳健投资者角度，简要评价这一信号的意义和需要注意的风险。
"""
    else:
        prompt = f"""
股票：{code}（{name}）
最近60日价格和成交量数据已用于计算 MA5、MA20 和 5日均量。

策略结果：
- 最近 5 个交易日内未出现“MA5 上穿 MA20 且成交量放大”的信号。
- 最新收盘价：{logic['last_close']:.2f}
- 最新 MA5：{logic['last_ma5']}, MA20：{logic['last_ma20']}

请用不超过100字，说明在当前均线结构下，这只股票更偏向上涨、震荡还是回调阶段，并给出简短的风险提示。
"""

    system = "你是一个A股技术分析助手，风格稳健、客观，不给出具体买卖建议。"
    answer = gemini_ask(prompt, system=system)
    print("\nGemini 解读：\n", answer)

if __name__ == "__main__":
    main()
