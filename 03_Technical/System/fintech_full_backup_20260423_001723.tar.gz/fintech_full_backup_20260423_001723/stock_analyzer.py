import pandas as pd
from sqlalchemy import create_engine

# 数据库连接配置 (必须与 Docker 配置一致)
DB_URL = "postgresql://postgres:fintech123@localhost:5432/fintech_db"

def run_analysis():
    print("📊 正在从数据库提取数据进行分析...")
    engine = create_engine(DB_URL)
    
    try:
        # 从数据库加载之前存入的 100 条行情数据
        # 注意：如果表不存在，请先运行菜单第 4 项
        df = pd.read_sql("SELECT * FROM test_stock_spot", engine)
        
        # 转换数据类型，确保涨跌幅是数字类型以便排序
        df['涨跌幅'] = pd.to_numeric(df['涨跌幅'], errors='coerce')
        
        # 筛选出涨幅最大的前 10 名
        top_10 = df.nlargest(10, '涨跌幅')[['代码', '名称', '最新价', '涨跌幅']]
        
        print("\n" + "★"*20)
        print("📈 今日行情涨幅排行榜 (Top 10)")
        print("★"*20)
        if not top_10.empty:
            print(top_10.to_string(index=False))
        else:
            print("表中没有数据，请先执行菜单第 4 项抓取数据。")
        print("★"*20)
        
    except Exception as e:
        print(f"❌ 分析出错: {e}")
        print("提示：请确保数据库容器已启动，并且已经运行过数据抓取。")

if __name__ == "__main__":
    run_analysis()
