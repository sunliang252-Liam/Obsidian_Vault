import akshare as ak
import pandas as pd
from sqlalchemy import create_engine
import datetime

# 1. 配置数据库连接
# 格式: postgresql://用户名:密码@地址:端口/数据库名
# 注意：密码需与你在 Docker 配置脚本中设置的 fintech123 一致
DB_URL = "postgresql://postgres:fintech123@localhost:5432/fintech_db"

def test_data_flow():
    print(f"[{datetime.datetime.now()}] 🚀 开始数据流验证...")

    try:
        # 2. 从 Akshare 抓取 A 股实时行情 (不需要 Token，适合立即测试)
        print("正在从接口抓取 A 股实时行情数据...")
        # 获取 A 股实时行情快照
        stock_zh_a_spot_df = ak.stock_zh_a_spot_em()
        
        # 只要前 100 条做测试
        test_df = stock_zh_a_spot_df.head(100)
        print(f"成功抓取到 {len(test_df)} 条行情数据。")

        # 3. 连接数据库并写入
        print("正在连接数据库并写入数据...")
        # 创建数据库引擎
        engine = create_engine(DB_URL)
        
        # 将数据写入名为 'test_stock_spot' 的表，如果表存在则替换 (replace)
        test_df.to_sql('test_stock_spot', engine, if_exists='replace', index=False)
        
        print("✅ 数据写入数据库成功！")

        # 4. 验证读取
        print("正在从数据库回读数据以验证一致性...")
        check_df = pd.read_sql("SELECT count(*) as total FROM test_stock_spot", engine)
        print(f"数据库中 'test_stock_spot' 表目前的记录数为: {check_df['total'][0]}")
        
        print("\n🎉 恭喜！你的 Fintech 系统全链路已通。")
        print("你可以开始构建你的量化分析逻辑了。")

    except Exception as e:
        print(f"❌ 验证过程中出现错误: {e}")
        print("\n[排错提示]")
        print("1. 检查 Docker: docker ps 是否看到 fintech_pg 在运行")
        print("2. 检查驱动: 是否执行了 pip install psycopg2-binary")
        print("3. 检查网络: Akshare 抓取数据需要网络连接")

if __name__ == "__main__":
    test_data_flow()
