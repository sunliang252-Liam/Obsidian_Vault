import akshare as ak
import pandas as pd
from sqlalchemy import create_engine
from tqdm import tqdm
import time

# 数据库连接
DB_URL = "postgresql://postgres:fintech123@localhost:5432/fintech_db"

def fetch_history_data():
    engine = create_engine(DB_URL)
    
    # 1. 从刚才的快照表中读取股票代码
    print("读取待处理的股票列表...")
    try:
        stocks_df = pd.read_sql("SELECT 代码 FROM test_stock_spot", engine)
        stock_list = stocks_df['代码'].tolist()
    except Exception as e:
        print(f"读取失败，请先运行数据抓取测试: {e}")
        return

    print(f"准备抓取 {len(stock_list)} 只股票的历史 K 线 (最近 30 天)...")
    
    all_history = []
    
    # 2. 循环抓取每只股票的历史数据
    for code in tqdm(stock_list):
        try:
            # 获取日线数据
            df = ak.stock_zh_a_hist(symbol=code, period="daily", start_date="20240101", adjust="qfq")
            if not df.empty:
                df['股票代码'] = code
                # 只取最近 30 条
                all_history.append(df.tail(30))
            # 避免请求过快被封 IP
            time.sleep(0.1)
        except:
            continue

    if all_history:
        # 合并所有数据
        final_df = pd.concat(all_history, ignore_index=True)
        
        # 3. 存入数据库的 stock_daily 表
        print(f"\n正在将 {len(final_df)} 条历史记录存入数据库...")
        final_df.to_sql('stock_daily', engine, if_exists='replace', index=False)
        print("✅ 历史数据同步完成！")
    else:
        print("未获取到任何历史数据。")

if __name__ == "__main__":
    fetch_history_data()
