# ~/fintech_system/strategies_ma_cross.py
import pandas as pd

def add_ma_and_vol(df: pd.DataFrame) -> pd.DataFrame:
    """
    假设 df 至少有: trade_date, close, vol
    返回新增 MA5、MA20、均量5
    """
    df = df.copy()
    df["ma5"] = df["close"].rolling(window=5).mean()
    df["ma20"] = df["close"].rolling(window=20).mean()
    df["vol5"] = df["vol"].rolling(window=5).mean()
    return df

def detect_ma5_cross_ma20_with_volume(df: pd.DataFrame, lookback: int = 5) -> dict:
    """
    检测最近 lookback 天内是否出现:
    - MA5 上穿 MA20（金叉）
    - 且当天成交量 > 最近5日平均成交量 * 1.2

    返回一个 dict，包含:
    - has_signal: bool 是否存在信号
    - cross_date: 发生日期（如果有）
    - last_close: 最近收盘价
    - last_ma5, last_ma20
    """
    if df.empty or len(df) < max(20, lookback + 1):
        return {"has_signal": False}

    df = add_ma_and_vol(df)
    df = df.sort_values("trade_date").reset_index(drop=True)

    # 只看最近 lookback 天，窗口向前多取一天用于判断“前一天在下方”
    sub = df.iloc[-(lookback + 1):].copy()

    signal_row = None
    for i in range(1, len(sub)):
        prev = sub.iloc[i-1]
        curr = sub.iloc[i]

        # 条件1：昨天 ma5 <= ma20，今天 ma5 > ma20 （上穿）
        cond_cross = (prev["ma5"] is not pd.NA and
                      prev["ma20"] is not pd.NA and
                      curr["ma5"] is not pd.NA and
                      curr["ma20"] is not pd.NA and
                      prev["ma5"] <= prev["ma20"] and
                      curr["ma5"] > curr["ma20"])

        # 条件2：放量，今日成交量 > 5日均量的 1.2 倍
        vol5 = curr.get("vol5")
        cond_volume = (
            vol5 is not None
            and not pd.isna(vol5)
            and vol5 > 0
            and curr["vol"] > vol5 * 1.2
        )

        if cond_cross and cond_volume:
            signal_row = curr
            break

    last = df.iloc[-1]

    result = {
        "has_signal": signal_row is not None,
        "cross_date": None,
        "last_close": float(last["close"]),
        "last_ma5": float(last["ma5"]) if not pd.isna(last["ma5"]) else None,
        "last_ma20": float(last["ma20"]) if not pd.isna(last["ma20"]) else None,
    }

    if signal_row is not None:
        result["cross_date"] = str(signal_row["trade_date"])

    return result
